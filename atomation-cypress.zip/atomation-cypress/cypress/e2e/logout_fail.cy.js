import HomePage from '../pages/homePage';

describe('Logout Fail Test', () => {
  it('Should fail to logout when not logged in', () => {
    cy.visit('https://www.saucedemo.com/');
    HomePage.openMenu();
    cy.get('#logout_sidebar_link').should('not.be.visible');
  });
});
