import LoginPage from '../pages/loginPage';
import HomePage from '../pages/homePage';

describe('Logout Pass Test', () => {
  it('Should logout successfully', () => {
    LoginPage.visit();
    LoginPage.enterUsername('standard_user');
    LoginPage.enterPassword('secret_sauce');
    LoginPage.clickLogin();

    HomePage.openMenu();
    HomePage.clickLogout();
    HomePage.verifyLogoutSuccess();
  });
});
