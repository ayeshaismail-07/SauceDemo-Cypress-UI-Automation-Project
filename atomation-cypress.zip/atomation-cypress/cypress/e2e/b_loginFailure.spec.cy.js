import LoginPage from '../pages/loginPage';

describe('Login Fail Test', () => {
  it('Should show error with invalid credentials', () => {
    LoginPage.visit();
    LoginPage.enterUsername('invalid_user');
    LoginPage.enterPassword('wrong_pass');
    LoginPage.clickLogin();
    LoginPage.verifyLoginFailed();
  });
});
