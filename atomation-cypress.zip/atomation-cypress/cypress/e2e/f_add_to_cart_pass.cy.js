import LoginPage from '../pages/loginPage';
import CartPage from '../pages/cartPage';
import HomePage from '../pages/homePage';

describe('Add to Cart Pass Test', () => {
  it('Should add item to cart successfully', () => {
    LoginPage.visit();
    LoginPage.enterUsername('standard_user');
    LoginPage.enterPassword('secret_sauce');
    LoginPage.clickLogin();

    CartPage.addItemToCart();
    CartPage.openCart();
    cy.get('.cart_item').should('be.visible');
  });
});
