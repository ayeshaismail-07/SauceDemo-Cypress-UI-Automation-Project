describe('Login Pass Test using Custom Command', () => {
  it('Should login successfully with valid credentials', () => {
    cy.login('standard_user', 'secret_sauce');   // ← uses your new command
    cy.get('.title').should('contain', 'Products'); // confirms login worked
  });
});
