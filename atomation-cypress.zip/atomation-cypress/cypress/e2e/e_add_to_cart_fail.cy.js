import LoginPage from '../pages/loginPage';
import CartPage from '../pages/cartPage';

describe('Add to Cart Fail Test', () => {
  it('Should fail if user not logged in', () => {
    // Intentionally not logging in
    cy.visit('https://www.saucedemo.com/inventory.html');
    CartPage.addItemToCart();
    // Expect failure because login was not done
    cy.get('[data-test="error"]').should('exist');
  });
});
