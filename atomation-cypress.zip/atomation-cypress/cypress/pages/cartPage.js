class CartPage {
  addItemToCart() {
    cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click();
  }

  openCart() {
    cy.get('.shopping_cart_link').click();
  }

  removeItem() {
    cy.get('[data-test="remove-sauce-labs-backpack"]').click();
  }

  verifyItemRemoved() {
    cy.get('.cart_item').should('not.exist');
  }
}

export default new CartPage();
